# Knowledge Base (Departments)
departments = {
    "CS": {
        "skills": ["math", "programming", "algorithms"],
        "interest": "theory",
        "min_score": 70
    },
    "IT": {
        "skills": ["networking", "hardware", "database"],
        "interest": "system",
        "min_score": 60
    },
    "SE": {
        "skills": ["programming", "design", "testing"],
        "interest": "development",
        "min_score": 65
    },
    "DT": {
        "skills": ["multimedia", "graphics", "design"],
        "interest": "creative",
        "min_score": 55
    }
}

# ===== USER INPUT =====
full_name = input("Enter your full name: ")

print("Enter your skills (comma separated): ")
student_skills = input().lower().split(",")
student_skills = [skill.strip() for skill in student_skills]

student_interest = input("Enter your interest (theory/system/development/creative): ").lower().strip()
exam_score = int(input("Enter your exam score: "))


# ===== FUNCTION =====
def evaluate_departments():
    scores = {}

    for dept, data in departments.items():
        total = 0

        # Rule 3: Check exam score
        if exam_score < data["min_score"]:
            continue

        # Rule 1: Skill Matching
        for skill in student_skills:
            if skill in data["skills"]:
                total += 2

        # Rule 2: Interest Matching
        if student_interest == data["interest"]:
            total += 3

        # Rule 3: Exam Score
        total += 5

        scores[dept] = total

    return scores


# ===== DECISION =====
scores = evaluate_departments()

print("\n===== RESULT =====")
print("Student Name:", full_name)
print("Department Scores:", scores)

if scores:
    max_score = max(scores.values())
    best_departments = [d for d in scores if scores[d] == max_score]

    print("Recommended Department(s):", best_departments)
else:
    print("No suitable department found.")