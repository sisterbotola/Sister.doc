# Environment setup: 3 rooms (A, B, C) which can be 'Dirty' or 'Clean'
environment = {
    "A": "Dirty",
    "B": "Dirty",
    "C": "Dirty"
}

# Goal: All rooms must be clean
goal_state = {
    "A": "Clean",
    "B": "Clean",
    "C": "Clean"
}

# Function to show current environment state
def show_environment():
    print("\nCurrent Environment State:")
    for room, status in environment.items():
        print(f"Room {room}: {status}")
    print("-" * 30)

# Goal-based agent
def goal_based_agent(location):
    print(f"Agent starts in room {location}.")
    while environment != goal_state:  # Repeat until goal is achieved
        if environment[location] == "Dirty":
            # Clean the current room
            print(f"Cleaning room {location}.")
            environment[location] = "Clean"
        else:
            print(f"Room {location} is already clean.")
        
        # Move to next room if goal not reached
        if environment != goal_state:
            if location == "A":
                location = "B"
            elif location == "B":
                location = "C"
            elif location == "C":
                location = "A"
        show_environment()
    
    print("All rooms are clean! Goal achieved.")

# Start the agent in room A
goal_based_agent("A")