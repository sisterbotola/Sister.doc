# Vacuum Cleaner Agent and Environment Simulation

# Environment: rooms and their states
environment = {
    "A": "Dirty",
    "B": "Dirty"
}

# Initial location of agent
location = "A"

# Function to display environment state
def show_environment():
    print("\nEnvironment State:")
    for room, state in environment.items():
        print(room, ":", state)

# Agent simulation
for step in range(4):

    show_environment()
    print("Agent is at location:", location)

    # Percept
    status = environment[location]

    # Decision rules
    if status == "Dirty":
        print("Action: SUCK (Cleaning room)")
        environment[location] = "Clean"

    elif location == "A":
        print("Action: MOVE RIGHT")
        location = "B"

    elif location == "B":
        print("Action: MOVE LEFT")
        location = "A"

print("\nFinal Environment State:")
show_environment()