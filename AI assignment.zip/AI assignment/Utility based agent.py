# Simple Utility-Based Agent for 3 rooms (A, B, C)

# Initialize room status
rooms = {"A": "Dirty", "B": "Dirty", "C": "Dirty"}

# Start location
current_room = "A"
total_utility = 0

print(f"Agent starts in room {current_room}.\n")

# Keep acting until all rooms are clean
while "Dirty" in rooms.values():
    # Clean current room if dirty
    if rooms[current_room] == "Dirty":
        print(f"Cleaning room {current_room}. +10 utility")
        rooms[current_room] = "Clean"
        total_utility += 10
    else:
        # Move to the next dirty room
        for room in rooms:
            if rooms[room] == "Dirty":
                print(f"Moving from {current_room} to {room}. -2 utility")
                current_room = room
                total_utility -= 2
                break
    
    # Show current room status
    print("Current room status:", rooms, "\n")

print(f"All rooms are clean! Total utility: {total_utility}")