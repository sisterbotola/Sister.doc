# Rational Vacuum Cleaner Agent

# Environment (rooms and their states)
environment = {
    "A": "Dirty",
    "B": "Dirty"
}

# Agent starting location
location = "A"

# Performance score
performance = 0


def show_environment():
    print("\nEnvironment State:")
    for room, state in environment.items():
        print(room, ":", state)


# Simulation steps
for step in range(6):

    show_environment()
    print("Agent location:", location)

    status = environment[location]

    # Rational decision
    if status == "Dirty":
        print("Action: SUCK (Cleaning room)")
        environment[location] = "Clean"
        performance += 10

    else:
        if location == "A":
            print("Action: MOVE RIGHT (A → B)")
            location = "B"
        else:
            print("Action: MOVE LEFT (B → A)")
            location = "A"

        performance -= 1

    print("Current Performance Score:", performance)


print("\nFinal Environment State:")
show_environment()

print("Total Performance Score:", performance)