# Simple Reflex Vacuum Cleaner Agent

location = input("Enter current location (A/B): ")
status = input("Enter status (Dirty/Clean): ")

if status == "Dirty":
    print("Action: SUCK")

elif location == "A" and status == "Clean":
    print("Action: MOVE RIGHT")

elif location == "B" and status == "Clean":
    print("Action: MOVE LEFT")

else:
    print("Invalid input")