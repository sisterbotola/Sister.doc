# Model-Based Vacuum Cleaner Agent

# Actual environment
environment = {
    "A": "Dirty",
    "B": "Dirty"
}

# Agent's internal model (memory)
model = {
    "A": None,
    "B": None
}

# Starting location
location = "A"

# Function to show environment
def show_environment():
    print("\nEnvironment State:")
    for room in environment:
        print(room, ":", environment[room])

# Function to check if all rooms are clean
def all_clean():
    return environment["A"] == "Clean" and environment["B"] == "Clean"

print("Model-Based Vacuum Agent Simulation")

# Agent loop
while not all_clean():

    show_environment()
    print("Agent location:", location)

    # Percept
    status = environment[location]

    # Update internal model
    model[location] = status

    # Decision
    if status == "Dirty":
        print("Action: SUCK (Cleaning room)")
        environment[location] = "Clean"
        model[location] = "Clean"

    else:
        if location == "A":
            print("Action: MOVE RIGHT (A → B)")
            location = "B"
        else:
            print("Action: MOVE LEFT (B → A)")
            location = "A"

    print("Agent Model Memory:", model)

print("\nAll rooms are clean!")
show_environment()