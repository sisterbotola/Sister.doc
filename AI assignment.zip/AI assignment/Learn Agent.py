import random

# Rooms environment
rooms = ["A", "B", "C"]

# Learning table: stores past utility of actions for each room
# Initially, all actions have zero learned utility
learning_table = {
    "A": {"clean": 0, "move": 0},
    "B": {"clean": 0, "move": 0},
    "C": {"clean": 0, "move": 0}
}

# Utilities
CLEAN_UTILITY = 10
MOVE_UTILITY = -2

# Function to initialize environment (random dirty/clean rooms)
def initialize_environment():
    env = {}
    for room in rooms:
        env[room] = random.choice(["Dirty", "Clean"])
    return env

# Learning agent
def learning_agent(runs=5):
    for run in range(1, runs + 1):
        print(f"\n--- Run {run} ---")
        env = initialize_environment()
        current_room = random.choice(rooms)
        total_utility = 0

        print("Initial room status:", env)
        while "Dirty" in env.values():
            # Decide action based on past learning
            if env[current_room] == "Dirty":
                action = "clean"
            else:
                # Choose next room based on learned move utility (higher is better)
                other_rooms = [r for r in rooms if r != current_room]
                # Pick the room with the least negative move penalty (or random if equal)
                action = "move"
                current_room = max(other_rooms, key=lambda r: learning_table[r]["move"])
            
            # Perform action and calculate utility
            if action == "clean":
                if env[current_room] == "Dirty":
                    env[current_room] = "Clean"
                    utility = CLEAN_UTILITY
                else:
                    utility = 0
            else:
                utility = MOVE_UTILITY

            # Update learning table
            learning_table[current_room][action] += utility
            total_utility += utility

            print(f"Room {current_room}, Action: {action}, Utility: {utility}")
            print("Current room status:", env)

        print(f"Run {run} completed. Total utility: {total_utility}")

    print("\nLearning table after all runs:")
    for room, actions in learning_table.items():
        print(f"{room}: {actions}")

# Run the learning agent
learning_agent(runs=5)